import './styles.css';
import LoginForm from '../../components/LoginForm/LoginForm';

function Homework18 () {
    return <div className="homework-container"><LoginForm/></div>
}

export default Homework18;
