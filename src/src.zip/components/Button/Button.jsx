import "./styles.css";
function Button() {
    return <button className="button" type="button">Create</button>;
  }
  
  export default Button;