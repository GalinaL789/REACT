const LogIn={
    placeholder: "Login",
    type:"text",
    label: "Input Login"
}

const Pwd={
    placeholder: "Password",
    type: "password",
    label: "Input password"
}
export {LogIn, Pwd}